
import streamlit as st
import joblib
import re
import nltk

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer

# 1. Streamlit Page Configuration
st.set_page_config(
    page_title="BBC News Classifier",
    page_icon="📰",
    layout="centered"
)

# 2. Application Title
st.title("📰 BBC News Classification")
st.write(
    "Enter a news article below to predict its category "
    "using Machine Learning."
)

st.markdown("---")

# 3. Download NLTK Resources
for resource in ['stopwords', 'punkt', 'punkt_tab', 'wordnet', 'omw-1.4']:
    nltk.download(resource, quiet=True)

# 4. Load Trained Model
@st.cache_resource
def load_model():
    model = joblib.load("models/naive_bayes_model.pkl")
    vectorizer = joblib.load("models/tfidf_vectorizer.pkl")
    return model, vectorizer

try:
    nb_classifier, tfidf_vectorizer = load_model()

except FileNotFoundError:
    st.error(
        "Model files not found! "
        "Please save your trained model inside the models folder."
    )
    st.stop()

# 5. Text Preprocessing
stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

def clean_text(text):

    if not isinstance(text, str):
        return ""

    # Remove HTML tags
    text = re.sub(r'<.*?>', '', text)

    # Remove non-alphabetic characters
    text = re.sub(r'[^a-zA-Z]', ' ', text)

    # Convert to lowercase
    text = text.lower()

    # Tokenization
    tokens = word_tokenize(text)

    # Remove stopwords
    tokens = [
        word for word in tokens
        if word not in stop_words
    ]

    # Lemmatization
    tokens = [
        lemmatizer.lemmatize(word)
        for word in tokens
    ]

    return ' '.join(tokens)

# 6. User Input
user_input = st.text_area(
    "Enter your news article:",
    height=200,
    placeholder="Paste your news article here..."
)

# 7. Predict News Category
if st.button("Predict News Category", type="primary"):

    if not user_input.strip():

        st.warning("Please enter a news article first.")

    else:

        cleaned_article = clean_text(user_input)

        if not cleaned_article.strip():

            st.warning("Please enter meaningful article text.")

        else:

            # Convert article into TF-IDF features
            article_vector = tfidf_vectorizer.transform(
                [cleaned_article]
            )

            # Predict category
            prediction = nb_classifier.predict(
                article_vector
            )[0]

            # Calculate prediction probabilities
            probabilities = nb_classifier.predict_proba(
                article_vector
            )[0]

            confidence = max(probabilities) * 100

            # Display prediction
            st.success(
                f"Predicted Category: {prediction.upper()}"
            )

            st.metric(
                "Prediction Confidence",
                f"{confidence:.2f}%"
            )

            # Display category probabilities
            st.subheader("Category Probabilities")

            for category, probability in zip(
                nb_classifier.classes_,
                probabilities
            ):

                st.write(f"**{category.capitalize()}**")

                st.progress(float(probability))

# 8. Footer
st.markdown("---")

st.caption(
    "BBC News Classification Project | "
    "TF-IDF + Multinomial Naive Bayes"
)
